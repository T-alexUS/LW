﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LW2_Таицкий
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] z = { -15, -14, -13, -12, -11, -10, -9, -8, -7, -6, -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20 };

            int s = 0;
            int p = 1;

            for (int i = 0; i < z.Length; i++)
            {
                if (z[i] % 2 == 0 && z[i] < 3)
                {
                    s += z[i];
                }
                else if (z[i] % 2 == 1 && z[i] > 1)
                {
                    p *= z[i];
                }
            }

            int r = s + p;
            label2.Text = r.ToString();

        }
    }
}
