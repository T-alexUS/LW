﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LW2_Таицкий
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string digits = "";
            string signes = "";
            string others = "";

            string mainString = textBox1.Text;

            for (int i = 0; i < mainString.Length; i++)
            {
                if (Char.IsDigit(mainString[i])) {
                    digits += mainString[i];
                }
                else if (Char.IsLetter(mainString[i]))
                {
                    signes += mainString[i];
                }
                else
                {
                    others += mainString[i];
                }
            }

            textBox2.Text = digits;
            textBox3.Text = signes;
            textBox4.Text = others;
            
        }
    }
}
