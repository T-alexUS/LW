﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LW2_Таицкий
{
    public partial class Form2 : Form
    {
        public Form2()      
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();

            var controllersCount = new Dictionary<string, int>()
            {
                {"Buttons", 0},
                {"Labels", 0 },
                {"TextBoxes", 0 },
                {"RadioButtons", 0 },
                {"CheckBoxes", 0 },
                    
            };

            string controllersCountView = "";

            string[] elements = { "Buttons", "Labels", "TextBoxes", "RadioButtons", "CheckBoxes" };
            Random rand = new Random();
            
            for (int i = 0; i < 7; i++)
            {
                string element = elements[(rand.Next(0, 5))];

                if (element == "Buttons")
                {
                    controllersCount["Buttons"] += 1;
                    Button button = new Button()
                    {
                        Width = 70,
                        Location = new Point(rand.Next(100, 300), rand.Next(50, 150)),                        
                    };
                    panel1.Controls.Add(button);
                }

                else if (element == "Labels")
                {
                    controllersCount["Labels"] += 1;
                    Label label = new Label()
                    {
                        Width = 70,
                        Text = "Labelism",
                        Location = new Point(rand.Next(200, 500), rand.Next(50, 150)),
                        BorderStyle = BorderStyle.FixedSingle,
                    };
                    panel1.Controls.Add(label);
                }

                else if (element == "TextBoxes")
                {
                    controllersCount["TextBoxes"] += 1;
                    TextBox textBox = new TextBox()
                    {
                        Width = 70,
                        Location = new Point(rand.Next(200, 500), rand.Next(50, 150)),
                        BorderStyle= BorderStyle.FixedSingle,
                    };
                    panel1.Controls.Add(textBox);
                }

                else if (element == "RadioButtons")
                {
                    controllersCount["RadioButtons"] += 1;
                    RadioButton radioButton = new RadioButton()
                    {
                        Width = 20,
                        Location = new Point(rand.Next(200, 500), rand.Next(50, 150)),
                    };
                    panel1.Controls.Add(radioButton);
                }

                else if (element == "CheckBoxes")
                {
                    controllersCount["CheckBoxes"] += 1;
                    CheckBox checkBox = new CheckBox()
                    {
                        Width = 20,
                        Location = new Point(rand.Next(200, 500), rand.Next(50, 150))
                    };
                    panel1.Controls.Add(checkBox);
                }

            }

            ICollection<string> keys = controllersCount.Keys;
            foreach(string key in keys)
            {
                controllersCountView += key + " = " + controllersCount[key] + "\n";
            }
            label1.Text = controllersCountView;

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
