﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LW2_Таицкий
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            dataGridView2.Rows.Clear();
            dataGridView1.RowCount = 9;
            dataGridView1.ColumnCount = 9;
            dataGridView2.RowCount = 9;
            dataGridView2.ColumnCount = 9;
            int i, j;

            int[,] arr = new int[9, 9];
            int[,] arr2 = new int[9, 9];

            //Заполнение системного массива числами
            Random random = new Random();
            for (i = 0; i < 9; i++)
            {
                for (j = 0; j < 9; j++)
                {
                    arr[i, j] = random.Next(-50, 50);
                }
            }

            for (i = 0; i < 9; i++)
            {
                for (j = 0; j < 9; j++)
                {
                    dataGridView1.Rows[i].Cells[j].Value = arr[i, j].ToString();
                }
            }

            for (i = 0; i < 9; i++)
            {
                int min = arr[i, 0];
                for (j = 0; j < 9; j++)
                {
                    if (min > arr[i, j])
                    {
                        min = arr[i, j];
                    }
                }
                arr2[i, 0] = min;
                for (j = 1; j < 9; j++)
                {
                    arr2[i, j] = arr[i, j];
                }

                for (i = 0; i < 9; i++)
                {
                    for (j = 0; j < 9; j++)
                    {
                        dataGridView2.Rows[i].Cells[j].Value = arr2[i, j].ToString();
                    }
                }


            }
        }
    }
}
