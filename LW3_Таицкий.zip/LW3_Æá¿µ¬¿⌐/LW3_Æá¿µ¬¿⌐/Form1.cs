using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LW3_Таицкий
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void DeleteSelectedStrings(ListBox listbox)
        {
            for (int i = listbox.Items.Count - 1; i >= 0; i--)
            {
                if (listbox.GetSelected(i)) listbox.Items.RemoveAt(i);
            }
        }

        private void AZSort(ListBox listBox)
        {
            List<String> list = new List<String>();
            foreach (var item in listBox.Items)
            {
                list.Add(item.ToString());
            }
            list.Sort();
            listBox.Items.Clear();
            foreach (var item in list)
            {
                listBox.Items.Add(item);
            }
        }

        private void ZASort(ListBox listBox)
        {
            List<String> list = new List<String>();
            foreach (var item in listBox.Items)
            {
                list.Add(item.ToString());
            }
            list.Sort();
            list.Reverse();
            listBox.Items.Clear();
            foreach (var item in list)
            {
                listBox.Items.Add(item);
            }
        }

        private void LengthAZ (ListBox listBox)
        {
            List<String> list = new List<string>();
            foreach (var item in listBox.Items)
            {
                list.Add(item.ToString());
            }
            listBox.Items.Clear();
            var sortResult = list.OrderBy(x => x.Length);
            foreach (var item in sortResult)
            {
                listBox.Items.Add(item);
            }
        }

        private void LengthZA(ListBox listBox)
        {
            List<String> list = new List<string>();
            foreach (var item in listBox.Items)
            {
                list.Add(item.ToString());
            }
            listBox.Items.Clear();
            var sortResult = list.OrderByDescending(x => x.Length);
            foreach (var item in sortResult)
            {
                listBox.Items.Add(item);
            }
        }

        private void открытьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog OpenDlg = new OpenFileDialog();
            if (OpenDlg.ShowDialog() == DialogResult.OK)
            {
                StreamReader Reader = new StreamReader(OpenDlg.FileName, Encoding.Default);
                richTextBox1.Text = Reader.ReadToEnd();
                Reader.Close();
            }
            OpenDlg.Dispose();
        }

        private void сохранитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog SaveDlg = new SaveFileDialog();
            if (SaveDlg.ShowDialog() == DialogResult.OK)
            {
                StreamWriter Writer = new StreamWriter(SaveDlg.FileName);
                for (int i = 0; i< listBox2.Items.Count; i++)
                {
                    Writer.WriteLine((string)listBox2.Items[i]);
                }                   
                Writer.Close();
            }
            SaveDlg.Dispose();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            listBox1.BeginUpdate();
            string[] Strings = richTextBox1.Text.Split(new char[] { '\n', '\t', ' ' },
            StringSplitOptions.RemoveEmptyEntries);
            foreach (string s in Strings)
            {
                string Str = s.Trim();
                if (Str == String.Empty) continue;
                if (radioButton1.Checked) listBox1.Items.Add(Str);
                if (radioButton2.Checked)
                {
                    if (Regex.IsMatch(Str, @"\d")) listBox1.Items.Add(Str);
                }
                if (radioButton3.Checked)
                {
                    if (Regex.IsMatch(Str, @"\w+@\w+\.\w+")) listBox1.Items.Add(Str);
                }
            }
            listBox1.EndUpdate();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            listBox3.Items.Clear();
            richTextBox1.Clear();
            textBox1.Clear();
            radioButton1.Checked = true;
            checkBox1.Checked = true;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            listBox2.Items.Clear ();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            listBox3.Items.Clear();
            string Find = textBox1.Text;
            if (checkBox1.Checked)
            {
                foreach (string String in listBox1.Items)
                {
                    if (String.Contains(Find)) listBox3.Items.Add(String);
                }
            }
            if (checkBox2.Checked)
            {
                foreach (string String in listBox2.Items)
                {
                    if (String.Contains(Find)) listBox3.Items.Add(String);
                }

            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Form2 AddRec = new Form2
            {
                Owner = this
            };
            AddRec.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            DeleteSelectedStrings(listBox1);
            DeleteSelectedStrings(listBox2);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox2.BeginUpdate();
            for (int i = 0; i <= listBox2.SelectedIndices.Count - 1; i++)
            {
                listBox2.Items.Add(listBox1.Items[i]);
                listBox1.Items.RemoveAt(i);
            }
            listBox2.EndUpdate();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.BeginUpdate();
            for (int i = 0; i <= listBox1.SelectedIndices.Count - 1; i++)
            {
                listBox1.Items.Add(listBox2.Items[i]);
                listBox2.Items.RemoveAt(i);
            }
            listBox1.EndUpdate();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox2.Items.AddRange(listBox1.Items);
            listBox1.Items.Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            listBox1.Items.AddRange(listBox2.Items);
            listBox2.Items.Clear();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int sortType = comboBox1.SelectedIndex;
            switch (sortType)
            {
                case 0:
                    AZSort(listBox2);
                    break;
                case 1:
                    ZASort(listBox2);
                    break;
                case 2:
                    LengthAZ(listBox2);
                    break;
                case 3:
                    LengthZA(listBox2);
                    break;
                default: break;
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            int sortType = comboBox2.SelectedIndex;
            switch (sortType)
            {
                case 0:
                    AZSort(listBox2);
                    break;
                case 1:
                    ZASort(listBox2);
                    break;
                case 2:
                    LengthAZ(listBox2);
                    break;
                case 3:
                    LengthZA(listBox2);
                    break;
                default: break;
            }
        }
    }
}