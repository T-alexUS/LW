﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LW2_Таицкий
{
    public partial class Form2 : Form
    {
        public Form2()      
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();

            var controllersCount = new Dictionary<string, int>()
            {
                {"Buttons", 0},
                {"Labels", 0 },
                {"TextBoxes", 0 },
                {"RadioButtons", 0 },
                {"CheckBoxes", 0 },
                    
            };

            string controllersCountView = "";

            string[] elements = { "Buttons", "Labels", "TextBoxes", "RadioButtons", "CheckBoxes" };
            Random rand = new Random();
            
            for (int i = 0; i < 10; i++)
            {
                string element = elements[(rand.Next(0, 7))];

                if (element == "Buttons")
                {
                    controllersCount["Buttons"]++;
                    Button button = new Button();
                    {
                        Size = new Size(30, 60);
                        Location = new Point(rand.Next(900, 300), rand.Next(900, 300));
                    };
                    panel1.Controls.Add(button);
                }

                else if (element == "Labels")
                {
                    controllersCount["Labels"]++;
                    Label label = new Label();
                    {
                        Size = new Size(30, 60);
                        Location = new Point(rand.Next(900, 300), rand.Next(900, 300));
                    };
                    panel1.Controls.Add(label);
                }

                else if (element == "TextBoxes")
                {
                    controllersCount["Textboxes"]++;
                    TextBox textBox = new TextBox();
                    {
                        Size = new Size(30, 60);
                        Location = new Point(rand.Next(900, 300), rand.Next(900, 300));
                    };
                    panel1.Controls.Add(textBox);
                }

                else if (element == "RadioButtons")
                {
                    controllersCount["RadioButtons"]++;
                    RadioButton radioButton = new RadioButton();
                    {
                        Size = new Size(30, 60);
                        Location = new Point(rand.Next(900, 300), rand.Next(900, 300));
                    };
                    panel1.Controls.Add(radioButton);
                }

                else if (element == "CheckBoxes")
                {
                    controllersCount["CheckBoxes"]++;
                    CheckBox checkBox = new CheckBox();
                    {
                        Size = new Size(30, 60);
                        Location = new Point(rand.Next(900, 300), rand.Next(900, 300));
                    };
                    panel1.Controls.Add(checkBox);
                }

            }

            //ICollection<string> keys = controlCount.Keys;
            //foreach (string key in keys)
            //{
            //    controlCountView += String.Format("{0} -> {1} \n", key, controlCount[key]);
            //}
            //label3.Text = controlCountView;


        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
