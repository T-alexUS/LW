﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace lab4
{
    public partial class Form5 : Form
    {
        
        public Form5()
        {
            
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
        public Color CircleColor
        {
            get
            {
                //если выбрана первая радиокнопка, то вернуть черный цвет
                if (radioButton1.Checked) return Color.Black;
                if (radioButton2.Checked) return Color.Gray;
                if (radioButton3.Checked) return Color.Red;
                if (radioButton4.Checked) return Color.Yellow;
                if (radioButton5.Checked) return Color.Green;
                return Color.Blue;
            }
            set
            {
                //если текущий цвет круга - черный, то сделать выбранной первую радиокнопку
                if (value == Color.Black) radioButton1.Checked = true;
                if (value == Color.Gray) radioButton2.Checked = true;
                if (value == Color.Red) radioButton3.Checked = true;
                if (value == Color.Yellow) radioButton4.Checked = true;
                if (value == Color.Green) radioButton5.Checked = true;
                if (value == Color.Blue) radioButton6.Checked = true;
            }
        }
    }
}