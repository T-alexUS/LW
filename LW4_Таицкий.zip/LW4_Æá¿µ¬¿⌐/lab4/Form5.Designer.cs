﻿using System.ComponentModel;

namespace lab4
{
    partial class Form5
        {
            /// <summary>
            /// Required designer variable.
            /// </summary>
            private System.ComponentModel.IContainer components = null;
    
            /// <summary>
            /// Clean up any resources being used.
            /// </summary>
            /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
            protected override void Dispose(bool disposing)
            {
                if (disposing && (components != null))
                {
                    components.Dispose();
                }
                base.Dispose(disposing);
            }
    
            #region Windows Form Designer generated code
    
            /// <summary>
            /// Required method for Designer support - do not modify
            /// the contents of this method with the code editor.
            /// </summary>
            private void InitializeComponent()
            {
                this.components = new System.ComponentModel.Container();
                System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form5));
                this.radioButton1 = new System.Windows.Forms.RadioButton();
                this.radioButton2 = new System.Windows.Forms.RadioButton();
                this.radioButton3 = new System.Windows.Forms.RadioButton();
                this.radioButton4 = new System.Windows.Forms.RadioButton();
                this.radioButton5 = new System.Windows.Forms.RadioButton();
                this.radioButton6 = new System.Windows.Forms.RadioButton();
                this.button1 = new System.Windows.Forms.Button();
                this.imageList1 = new System.Windows.Forms.ImageList(this.components);
                this.button2 = new System.Windows.Forms.Button();
                this.groupBox1 = new System.Windows.Forms.GroupBox();
                this.groupBox1.SuspendLayout();
                this.SuspendLayout();
                // 
                // radioButton1
                // 
                this.radioButton1.AutoSize = true;
                this.radioButton1.Checked = true;
                this.radioButton1.Location = new System.Drawing.Point(8, 23);
                this.radioButton1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
                this.radioButton1.Name = "radioButton1";
                this.radioButton1.Size = new System.Drawing.Size(78, 20);
                this.radioButton1.TabIndex = 0;
                this.radioButton1.TabStop = true;
                this.radioButton1.Text = "Черный";
                this.radioButton1.UseVisualStyleBackColor = true;
                // 
                // radioButton2
                // 
                this.radioButton2.AutoSize = true;
                this.radioButton2.Location = new System.Drawing.Point(8, 53);
                this.radioButton2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
                this.radioButton2.Name = "radioButton2";
                this.radioButton2.Size = new System.Drawing.Size(70, 20);
                this.radioButton2.TabIndex = 1;
                this.radioButton2.Text = "Серый";
                this.radioButton2.UseVisualStyleBackColor = true;
                // 
                // radioButton3
                // 
                this.radioButton3.AutoSize = true;
                this.radioButton3.Location = new System.Drawing.Point(8, 82);
                this.radioButton3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
                this.radioButton3.Name = "radioButton3";
                this.radioButton3.Size = new System.Drawing.Size(84, 20);
                this.radioButton3.TabIndex = 2;
                this.radioButton3.Text = "Красный";
                this.radioButton3.UseVisualStyleBackColor = true;
                // 
                // radioButton4
                // 
                this.radioButton4.AutoSize = true;
                this.radioButton4.Location = new System.Drawing.Point(163, 23);
                this.radioButton4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
                this.radioButton4.Name = "radioButton4";
                this.radioButton4.Size = new System.Drawing.Size(81, 20);
                this.radioButton4.TabIndex = 3;
                this.radioButton4.Text = "Желтый";
                this.radioButton4.UseVisualStyleBackColor = true;
                // 
                // radioButton5
                // 
                this.radioButton5.AutoSize = true;
                this.radioButton5.Location = new System.Drawing.Point(163, 53);
                this.radioButton5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
                this.radioButton5.Name = "radioButton5";
                this.radioButton5.Size = new System.Drawing.Size(86, 20);
                this.radioButton5.TabIndex = 4;
                this.radioButton5.Text = "Зеленый";
                this.radioButton5.UseVisualStyleBackColor = true;
                // 
                // radioButton6
                // 
                this.radioButton6.AutoSize = true;
                this.radioButton6.Location = new System.Drawing.Point(163, 82);
                this.radioButton6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
                this.radioButton6.Name = "radioButton6";
                this.radioButton6.Size = new System.Drawing.Size(69, 20);
                this.radioButton6.TabIndex = 5;
                this.radioButton6.Text = "Синий";
                this.radioButton6.UseVisualStyleBackColor = true;
                // 
                // button1
                // 
                this.button1.DialogResult = System.Windows.Forms.DialogResult.OK;
                this.button1.ImageIndex = 0;
                this.button1.ImageList = this.imageList1;
                this.button1.Location = new System.Drawing.Point(16, 134);
                this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
                this.button1.Name = "button1";
                this.button1.Size = new System.Drawing.Size(113, 28);
                this.button1.TabIndex = 6;
                this.button1.Text = "ОК";
                this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
                this.button1.UseVisualStyleBackColor = true;
                // 
                // imageList1
                // 
                this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
                this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
                this.imageList1.Images.SetKeyName(0, "kisspng-check-mark-x-mark-clip-art-check-marks-5a7c0970903068.7393423315180783205" +
            "906.png");
                this.imageList1.Images.SetKeyName(1, "57758834c8299155a31c0e54.png");
                // 
                // button2
                // 
                this.button2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
                this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
                this.button2.ImageIndex = 1;
                this.button2.ImageList = this.imageList1;
                this.button2.Location = new System.Drawing.Point(169, 134);
                this.button2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
                this.button2.Name = "button2";
                this.button2.Size = new System.Drawing.Size(113, 28);
                this.button2.TabIndex = 7;
                this.button2.Text = "Отмена";
                this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
                this.button2.UseVisualStyleBackColor = true;
                // 
                // groupBox1
                // 
                this.groupBox1.Controls.Add(this.radioButton1);
                this.groupBox1.Controls.Add(this.radioButton2);
                this.groupBox1.Controls.Add(this.radioButton3);
                this.groupBox1.Controls.Add(this.radioButton6);
                this.groupBox1.Controls.Add(this.radioButton4);
                this.groupBox1.Controls.Add(this.radioButton5);
                this.groupBox1.Location = new System.Drawing.Point(16, 4);
                this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
                this.groupBox1.Name = "groupBox1";
                this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
                this.groupBox1.Size = new System.Drawing.Size(267, 123);
                this.groupBox1.TabIndex = 8;
                this.groupBox1.TabStop = false;
                this.groupBox1.Text = "Цвет круга";
                // 
                // Form5
                // 
                this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
                this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
                this.ClientSize = new System.Drawing.Size(292, 171);
                this.Controls.Add(this.groupBox1);
                this.Controls.Add(this.button2);
                this.Controls.Add(this.button1);
                this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
                this.Name = "Form5";
                this.Text = "Выбор цвета";
                this.Load += new System.EventHandler(this.Form2_Load);
                this.groupBox1.ResumeLayout(false);
                this.groupBox1.PerformLayout();
                this.ResumeLayout(false);
    
            }
    
            #endregion
    
            private System.Windows.Forms.RadioButton radioButton1;
            private System.Windows.Forms.RadioButton radioButton2;
            private System.Windows.Forms.RadioButton radioButton3;
            private System.Windows.Forms.RadioButton radioButton4;
            private System.Windows.Forms.RadioButton radioButton5;
            private System.Windows.Forms.RadioButton radioButton6;
            private System.Windows.Forms.Button button1;
            private System.Windows.Forms.Button button2;
            private System.Windows.Forms.GroupBox groupBox1;
            private System.Windows.Forms.ImageList imageList1;
        }
}