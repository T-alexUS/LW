﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace lab4
{
    public partial class Form4 : Form
    {
        int x0, y0;
        int radius;
        int xDir, yDir;
        GraphicsPath path;
        Color myColor;

        public Form4()
        {
            myColor = Color.Yellow;
            InitializeComponent();
            x0 = pictureBox1.Width/2;
            y0 = pictureBox1.Height/2 - 35;
            radius = 30;
            xDir =-1;
            yDir = 1;
            path = new GraphicsPath();
        }
        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            //создаем графический объект
            Graphics g = e.Graphics;
            //очищаем область рисования
            g.Clear(Color.White);
            //создаем штриховую кисть желтого цвета
            HatchBrush brush = new HatchBrush(HatchStyle.SolidDiamond, myColor);
            //рисуем круг
            g.FillEllipse(brush, x0 - radius, y0 - radius, 2 * radius, 2 * radius);
            //очищаем фигуру
            path.Reset();
            //начинаем формирование фигуры
            path.StartFigure();
            path.AddEllipse(x0 - radius, y0 - radius, 2 * radius, 2 * radius);
            //завершаем формирование фигуры
            path.CloseFigure();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            timer1.Interval = trackBar1.Value;
        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                //получаем точку с координатами места щелчка
                Point pt = new Point(e.X, e.Y);
                //если эта точка - внутри фигуры (круга)
                if (path.IsVisible(pt))
                {
                    //создаем объект формы выбора цвета
                    Form5 form = new Form5();
                    //передаем в форму текущий цвет круга
                    form.CircleColor = myColor;
                    //отображаем форму на экране
                    if (form.ShowDialog() == DialogResult.OK)
                    {
                        //получаем значение выбранного цвета
                        myColor = form.CircleColor;
                        //перерисовываем круг
                        pictureBox1.Invalidate();
                    }
                }
            }
        }

        //кнопка "Stop"
        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
            if (x0 - radius < 0)
                xDir = 1; //то начинаем двигаться вправо
//если к правой стенке,
            if (x0 + radius + 5 > pictureBox1.Width)
                xDir = -1; //то влево
//если к верхней стенке,
            if (y0 - radius < 0)
                yDir = 1; //то вниз
            
//если к нижней стенке,
            if (y0 + radius + 5 > pictureBox1.Height)
                yDir = -1; //то вверх
//                            //изменяем координаты круга
            x0 += xDir;
            y0 += yDir;
            //обновляем область рисования (перерисовываем круг)
            pictureBox1.Invalidate();
        }

        
    }
}