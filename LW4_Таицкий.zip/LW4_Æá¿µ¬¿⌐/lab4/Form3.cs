﻿using System;
using System.Windows.Forms;

namespace lab4
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        private double f(double x)
        {
            return (Math.Pow(x, 2) + 1) / Math.Sin(3 * x) + Math.Sqrt(x / 2.0) / Math.Cos(3 * x);
        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(textBoxXmin.Text, out double Xmin) || !double.TryParse(textBoxXmax.Text, out double Xmax) || !double.TryParse(textBoxStep.Text, out double Step))
            {
                MessageBox.Show("Введите числа");
            }
            else
            {
                // Считываем с формы требуемые значения
                
                // Количество точек графика
                int count = (int)Math.Ceiling((Xmax - Xmin) / Step) + 1;
                // Массив значений X – общий для обоих графиков
                double[] x = new double[count];
                // Два массива Y – по одному для каждого графика
                double[] y1 = new double[count];
                double[] y2 = new double[count];
                // Расчитываем точки для графиков функции
                for (int i = 0; i < count; i++)
                {
                    // Вычисляем значение X
                    x[i] = Xmin + Step * i;
                    // Вычисляем значение функций в точке X
                    y1[i] = f(x[i]);
                    y2[i] = Math.Sin(x[i]);

                }
                // Настраиваем оси графика

                chart1.ChartAreas[0].AxisX.Minimum = Xmin;
                chart1.ChartAreas[0].AxisX.Maximum = Xmax;
                // Определяем шаг сетки
                chart1.ChartAreas[0].AxisX.MajorGrid.Interval = Step;
                // Добавляем вычисленные значения в графики
                chart1.Series[0].Points.DataBindXY(x, y1);
                chart1.Series[1].Points.DataBindXY(x, y2);
            }
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            textBoxXmin.Text = "0,2";
            textBoxXmax.Text = "2,2";
            textBoxStep.Text = "0,2";
            //this.TopMost = true;
            this.KeyPreview = true;

        }
       
    }
}