﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace lab4
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        Font font;
        SolidBrush brush;

        private void Form1_Load(object sender, EventArgs e)
        {

            //шрифт берем установленный по умолчанию 
            font = fontDialog1.Font;
            //создаем сплошную кисть черного цвета 
            brush = new SolidBrush(Color.Black);
        }

        private void button1_Click(object sender, EventArgs e)
        {

            //если выбор шрифта завершен нажатием кнопки OK 
            if (fontDialog1.ShowDialog() == DialogResult.OK)
            { //получить параметры шрифта из диалогового окна 
                font = fontDialog1.Font;
                //получить цвет шрифта из того же окна 
                brush.Color = fontDialog1.Color;
            }

        }

        private double fun(double x)
        {
            return (Math.Pow(x, 2) + 1) / Math.Sin(3 * x) + Math.Sqrt(x / 2.0) / Math.Cos(3 * x);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (numericUpDown1.Value==0 || numericUpDown1.Value == 1 || numericUpDown2.Value == 0) MessageBox.Show("Введите данные либо введите другие данные!");
            else
            {
                pictureBox1.Refresh();
            }
                
        }
        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            
            {
                //Начало координат графика 
                int x0 = 20;
                int y0 = (int)(pictureBox1.Height * 0.85);
                //Масштаб по оси Х
                int Mx = pictureBox1.Width - 2 * x0;
                //Масштаб по оси Y 
                int My = -y0 + 10;
                //Число точек графика
                int M = (int)numericUpDown1.Value;
                //Создание графического объекта 
                Graphics G = e.Graphics;
                //Очистка PictureBox1
                G.Clear(Color.White);
                //Описание и создание массива точек
                //Экранные координаты
                Point[] p = new Point[M];
                //Физические или реальные координаты
                PointF[] p2 = new PointF[M];
                //Цикл по числу точек графика 
                double j = 0.2;
                for (int n = 0; n < M && j <2.2; n++)
                {

                    //Физические координаты
                    //double x = (double)n / M;
                    double x = (0 + n); // M);
                    double y = fun(j);
                    j += 0.2;
                    //Экранные координаты 
                    int xi = (int)((x0 + Mx * x) / 4.5) +55;
                    int yi = (int)((y0 + My * y) / 10 +140);
                    //заносим в массив вычисленные значения координат 
                    p[n] = new Point(xi, yi);
                    p2[n] = new PointF((float)x, (float)y);
                }
                //коэффициент упругости графика
                float tensition = (float)numericUpDown2.Value;

                //рисование графика
                G.DrawCurve(Pens.Blue, p, tensition);

                //Рисование оси Х
                G.DrawLine(Pens.Black, x0, y0, x0 + Mx, y0);

                //Рисование оси Y 
                G.DrawLine(Pens.Black, x0, y0, x0, y0 + My);


                //Разметка оси Х 
                for (int n = 0; n <= 50; n += 5)
                {
                    //физическая координата штриха
                    double x1 = 0 + n * 0.1;
                    double x = n / 25.0;
                    //экранная координата штриха 
                    int xi = (int)(x0 + Mx * x);
                    //Наносим штрих 
                    G.DrawLine(Pens.Black, xi, y0, xi, y0 + 4);
                    //Наносим число
                    G.DrawString(x1.ToString(), font, brush, xi - 9, y0 + 4);
                }

                //Разметка оси У 
                for (int n = 0; n <= 200; n+=2)
                {
                    //физическая координата штриха 
                    double y = n / 40.0;
                    double y1 = -20  +n;
                    //экранная координата штриха 
                    int yi = (int)(y0 + My * y);
                    //Наносим штрих 
                    G.DrawLine(Pens.Black, x0, yi, x0 - 4, yi);
                    //Наносим число
                    G.DrawString(y1.ToString(), font, brush, x0 - 22, yi - 4);
                }
            }
 
        }
    }
}